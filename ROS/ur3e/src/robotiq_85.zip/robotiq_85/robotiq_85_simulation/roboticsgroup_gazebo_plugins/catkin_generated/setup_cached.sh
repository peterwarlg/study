#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/robot227/catkin_ws/src/robotiq_85/robotiq_85_simulation/roboticsgroup_gazebo_plugins/devel:$CMAKE_PREFIX_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/robot227/catkin_ws/src/robotiq_85/robotiq_85_simulation/roboticsgroup_gazebo_plugins/devel/share/common-lisp"
export ROS_PACKAGE_PATH="/home/robot227/catkin_ws/src/robotiq_85/robotiq_85_simulation/roboticsgroup_gazebo_plugins:/opt/ros/indigo/share:/opt/ros/indigo/stacks"