# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "".split(';') if "" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;gazebo_ros;control_toolbox".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "roboticsgroup_gazebo_plugins"
PROJECT_SPACE_DIR = "/home/robot227/catkin_ws/src/robotiq_85/robotiq_85_simulation/roboticsgroup_gazebo_plugins/devel"
PROJECT_VERSION = "0.0.1"
